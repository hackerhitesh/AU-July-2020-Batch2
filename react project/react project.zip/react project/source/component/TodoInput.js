import React, { Component } from 'react'


export default  class TodoInput extends Component {
    render() {
        return (
            <div>
             <h1>   hello from input</h1>
           
            </div>
        );
    }
}


