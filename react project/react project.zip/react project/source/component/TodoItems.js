import React, { Component } from 'react';
 import FlipMove from "react-flip-move";

class TodoItems extends Component {
   constructor(props) {
     super(props);
   
     this.createTasks = this.createTasks.bind(this); 
 }
  createTasks(item) {
    return <li key={item.key}>{item.text}</li>
  }
  delete(key){     
    this.props.delete(key);  
  }
  // addItem(e) {
  //   const itemArray = this.state.items;

  //   if (this._inputElement.value !== '') {
  //     itemArray.unshift({
  //       text: this._inputElement.value,
  //       key: Date.now()
  //     });

  //     this._inputElement.value = '';
  //   }
  //   console.log(itemArray);

  //   e.preventDefault();
  // }
   
  // deleteItem(key) {
  //   var filteredItems = this.state.items.filter(function (item) {
  //     return (item.key !== key);
  //   });
   
  //   this.setState({
  //     items: filteredItems
  //   });
  // }
    render() {
      var todoEntries = this.props.entries;
      var listItems = todoEntries.map(this.createTasks);
   
      return (
        <ul className="theList">
      <FlipMove duration={250} easing="ease-out">
        {listItems}
      </FlipMove>
    </ul>
      );
    }
  };
   
  export default TodoItems;